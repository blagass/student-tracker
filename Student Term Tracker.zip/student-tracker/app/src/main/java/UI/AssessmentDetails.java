package UI;


import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.tracker.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import database.Repository;
import entities.Assessment;
import entities.Course;

public class AssessmentDetails extends AppCompatActivity {
    int assessmentId;
    String sAssessmentName;
    EditText etAssessmentName;
    Repository repository;
    private String assessmentType;
    private RadioGroup assessmentButtonGroup;
    private RadioButton objectiveButton;
    private RadioButton performanceButton;
    private EditText assessmentStart, assessmentEnd;
    private final Calendar calendar = Calendar.getInstance();
    int courseId;
    private DatePickerDialog.OnDateSetListener startDatePickerListener;
    private DatePickerDialog.OnDateSetListener endDatePickerListener;

    Assessment currentAssessment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_assessment_details);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        repository = new Repository(getApplication());

        etAssessmentName = findViewById(R.id.assessmentNameEdit);

        assessmentId = getIntent().getIntExtra("id", -1);
        sAssessmentName = getIntent().getStringExtra("assessmentNameEdit");
        courseId = getIntent().getIntExtra("courseId", -1);

        String assessmentStartDate = getIntent().getStringExtra("startDate");
        String assessmentEndDate = getIntent().getStringExtra("endDate");

        assessmentStart = findViewById(R.id.etStartDate);
        assessmentEnd = findViewById(R.id.etEndDate);

        assessmentStart.setText(assessmentStartDate);
        assessmentEnd.setText(assessmentEndDate);

        assessmentStart.setFocusable(false);
        assessmentStart.setClickable(true);

        assessmentEnd.setFocusable(false);
        assessmentEnd.setClickable(true);

        etAssessmentName.setText(sAssessmentName);

        assessmentButtonGroup = findViewById(R.id.assessmentButtonGroup);
        objectiveButton = findViewById(R.id.objectiveButton);
        performanceButton = findViewById(R.id.performanceButton);

        courseId = getIntent().getIntExtra("courseId", -1);
        assessmentId = getIntent().getIntExtra("id", -1);


        if (courseId == -1 && assessmentId == -1) {
            finish();
            return;
        }

        assessmentButtonGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.objectiveButton) {
                assessmentType = "Objective";
            } else if (checkedId == R.id.performanceButton) {
                assessmentType = "Performance";
            }
        });

        if (assessmentId != -1) {
            Assessment assessment = repository.getmAllAssessments().stream()
                    .filter(a -> a.getAssessmentId() == assessmentId)
                    .findFirst()
                    .orElse(null);

            if (assessment != null) {
                loadDataIntoViews(assessment);
                courseId = assessment.getAssessmentCourseId();
            } else {
                Toast.makeText(this, "Assessment not found", Toast.LENGTH_SHORT).show();
                finish();
            }
        }

        startDatePickerListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, monthOfYear);
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateDateLabel(assessmentStart);
            }
        };

        endDatePickerListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, monthOfYear);
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateDateLabel(assessmentEnd);
            }
        };

        assessmentStart.setOnClickListener(v -> new DatePickerDialog(AssessmentDetails.this, startDatePickerListener,
                calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show());

        assessmentEnd.setOnClickListener(v -> new DatePickerDialog(AssessmentDetails.this, endDatePickerListener,
                calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show());


        //TYPE
        assessmentButtonGroup = findViewById(R.id.assessmentButtonGroup);
        objectiveButton = findViewById(R.id.objectiveButton);
        performanceButton = findViewById(R.id.performanceButton);

        assessmentButtonGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.objectiveButton) {
                assessmentType = "Objective";
            } else if (checkedId == R.id.performanceButton) {
                assessmentType = "Performance";
            }
        });

        if (assessmentId != -1) {
            Assessment assessment = repository.getmAllAssessments().stream()
                    .filter(a -> a.getAssessmentId() == assessmentId)
                    .findFirst()
                    .orElse(null);

            if (assessment != null) {
                assessmentType = assessment.getAssessmentType();
                if (assessmentType.equals("Objective")) {
                    objectiveButton.setChecked(true);
                } else {
                    performanceButton.setChecked(true);
                }
            }
        }


    }

    private void loadDataIntoViews(Assessment assessment) {
        etAssessmentName.setText(assessment.getAssessmentName());
        assessmentStart.setText(assessment.getAssessmentStartDate());
        assessmentEnd.setText(assessment.getAssessmentEndDate());
        assessmentType = assessment.getAssessmentType();
        if (assessmentType.equals("Objective")) {
            objectiveButton.setChecked(true);
        } else {
            performanceButton.setChecked(true);
        }
    }

    private void updateDateLabel(EditText dateEditText) {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        dateEditText.setText(sdf.format(calendar.getTime()));
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_assessmentdetails, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.assessmentdelete) {
            for (Assessment assessment : repository.getmAllAssessments()) {
                if (assessment.getAssessmentId() == assessmentId) {
                    currentAssessment = assessment;
                    break;
                }
            }
            if (currentAssessment != null) {
                repository.delete(currentAssessment);
                Toast.makeText(this, "Assessment Deleted!!", Toast.LENGTH_LONG).show();
                AssessmentDetails.this.finish();
            }
            return true;
        }

        if (item.getItemId() == R.id.assessmentcancel) {
            AssessmentDetails.this.finish();
            return true;
        }

        if (item.getItemId() == R.id.assessmentsave) {

            Assessment assessment;

            String start = assessmentStart.getText().toString();
            String end = assessmentEnd.getText().toString();

            if (assessmentId == -1) {

                courseId = getIntent().getIntExtra("courseId", -1);


                if (courseId == -1) {
                    Toast.makeText(this, "Wrong course ID", Toast.LENGTH_SHORT).show();
                    finish();
                    return true;
                }

                int newAssessmentId = 0;
                for (Assessment a : repository.getmAllAssessments()) {
                    if (a.getAssessmentCourseId() == courseId && a.getAssessmentId() > newAssessmentId) {
                        newAssessmentId = a.getAssessmentId();
                    }
                }
                newAssessmentId++;

                assessment = new Assessment(newAssessmentId, etAssessmentName.getText().toString(), assessmentType, start, end, courseId);
                repository.insert(assessment);
            } else {

                assessment = new Assessment(assessmentId, etAssessmentName.getText().toString(), assessmentType, start, end, courseId);
                repository.update(assessment);
            }

            dateSave();
            setResult(RESULT_OK);
            this.finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void dateSave() {

        String startText = assessmentStart.getText().toString();
        String endText = assessmentEnd.getText().toString();
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        Date dStartDate = null;
        Date dEndDate = null;

        try {
            dStartDate = sdf.parse(startText);
            dEndDate = sdf.parse(endText);
        } catch (ParseException e) {
            Toast.makeText(AssessmentDetails.this, "Invalid date format", Toast.LENGTH_SHORT).show();
        }

        long triggerStart = SystemClock.elapsedRealtime() + dStartDate.getTime() - System.currentTimeMillis();
        long triggerEnd = SystemClock.elapsedRealtime() + dEndDate.getTime() - System.currentTimeMillis();

        Intent startIntent = new Intent(AssessmentDetails.this, MyReceiver.class);
        startIntent.putExtra("key", "Assessment '" + etAssessmentName.getText().toString() + "' starting");
        PendingIntent startSender = PendingIntent.getBroadcast(AssessmentDetails.this, MainActivity.numAlert++, startIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent endIntent = new Intent(AssessmentDetails.this, MyReceiver.class);
        endIntent.putExtra("key", "Assessment '" + etAssessmentName.getText().toString() + "' ending");
        PendingIntent endSender = PendingIntent.getBroadcast(AssessmentDetails.this, MainActivity.numAlert++, endIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerStart, startSender);
        alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerEnd, endSender);
        Toast.makeText(AssessmentDetails.this, "Alerts set for Assessment start and end dates", Toast.LENGTH_SHORT).show();

    }
}
